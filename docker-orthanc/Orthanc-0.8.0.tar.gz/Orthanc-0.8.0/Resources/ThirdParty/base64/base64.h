#include <string>

std::string base64_encode(const std::string& stringToEncode);
std::string base64_decode(const std::string& s);
