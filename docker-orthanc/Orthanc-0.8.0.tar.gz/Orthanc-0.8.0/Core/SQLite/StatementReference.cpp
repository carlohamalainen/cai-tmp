/**
 * Orthanc - A Lightweight, RESTful DICOM Store
 * Copyright (C) 2012-2014 Medical Physics Department, CHU of Liege,
 * Belgium
 *
 * Copyright (c) 2012 The Chromium Authors. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *    * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *    * Neither the name of Google Inc., the name of the CHU of Liege,
 * nor the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/


#include "../PrecompiledHeaders.h"
#include "StatementReference.h"

#include "../OrthancException.h"

#include <cassert>
#include <glog/logging.h>
#include "sqlite3.h"

namespace Orthanc
{
  namespace SQLite
  {
    bool StatementReference::IsRoot() const
    {
      return root_ == NULL;
    }

    StatementReference::StatementReference()
    {
      root_ = NULL;
      refCount_ = 0;
      statement_ = NULL;
      assert(IsRoot());
    }

    StatementReference::StatementReference(sqlite3* database,
                                           const char* sql)
    {
      if (database == NULL || sql == NULL)
      {
        throw OrthancException(ErrorCode_ParameterOutOfRange);
      }

      root_ = NULL;
      refCount_ = 0;

      int error = sqlite3_prepare_v2(database, sql, -1, &statement_, NULL);
      if (error != SQLITE_OK)
      {
        throw OrthancException("SQLite: " + std::string(sqlite3_errmsg(database)));
      }

      assert(IsRoot());
    }

    StatementReference::StatementReference(StatementReference& other)
    {
      refCount_ = 0;

      if (other.IsRoot())
      {
        root_ = &other;
      }
      else
      {
        root_ = other.root_;
      }

      root_->refCount_++;
      statement_ = root_->statement_;

      assert(!IsRoot());
    }

    StatementReference::~StatementReference()
    {
      if (IsRoot())
      {
        if (refCount_ != 0)
        {
          // There remain references to this object. We cannot throw
          // an exception because:
          // http://www.parashift.com/c++-faq/dtors-shouldnt-throw.html

          LOG(ERROR) << "Bad value of the reference counter";
        }
        else if (statement_ != NULL)
        {
          sqlite3_finalize(statement_);
        }
      }
      else
      {
        if (root_->refCount_ == 0)
        {
          // There remain references to this object. We cannot throw
          // an exception because:
          // http://www.parashift.com/c++-faq/dtors-shouldnt-throw.html

          LOG(ERROR) << "Bad value of the reference counter";
        }
        else
        {
          root_->refCount_--;
        }
      }
    }

    uint32_t StatementReference::GetReferenceCount() const
    {
      return refCount_;
    }
  }
}
